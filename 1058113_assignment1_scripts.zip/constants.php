<?php
//define application constants
define('UPLOADPATH', 'images/');

?>