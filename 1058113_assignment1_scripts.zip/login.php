<html>
<body>
<?php
	$server = "mysql.ccacolchester.com";
	$user = "adrianl8113";
	$pass = "1058113";
	$database = "adrianl8113";
	//this section allows for quick changing to local details for testing
	//$localServer = "localhost";
	//$localUser = "root";
	//$localPass = "";
	//$localDatabase = "insert_name_of_database_here";
?>
</body>
</html>