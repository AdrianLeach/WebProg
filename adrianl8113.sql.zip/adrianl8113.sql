-- phpMyAdmin SQL Dump
-- version 3.3.10.4
-- http://www.phpmyadmin.net
--
-- Host: mysql.ccacolchester.com
-- Generation Time: Nov 21, 2014 at 02:06 AM
-- Server version: 5.1.56
-- PHP Version: 5.3.27

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `adrianl8113`
--

-- --------------------------------------------------------

--
-- Table structure for table `Content`
--

CREATE TABLE IF NOT EXISTS `Content` (
  `contentId` int(11) NOT NULL AUTO_INCREMENT,
  `owner` int(11) DEFAULT NULL,
  `title` varchar(50) NOT NULL,
  `content` varchar(500) NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `dateAdded` datetime DEFAULT NULL,
  PRIMARY KEY (`contentId`),
  KEY `owner` (`owner`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `Content`
--

INSERT INTO `Content` (`contentId`, `owner`, `title`, `content`, `image`, `dateAdded`) VALUES
(1, 1, 'Revised Times Table Game', 'This is a new test to determine whether a update query is working correctly', 'images/linux_mint.png', '2014-11-10 23:14:54'),
(2, 3, 'Xenomorph Survival Guide', 'This is a summary of the lessons life aboard an isolated space station have taught me.', NULL, '2150-09-21 00:00:00'),
(5, 20, 'The History of SHIELD', 'The earliest routes of SHIELD date back to the 1940s.  During bitter battles the world over the allied forces understood something extraordinary was required.', NULL, '2014-11-15 12:52:51'),
(6, 1, 'Designing A Webfolio', 'Here is a brief description of something to test prepared statements', 'images/linux_mint.png', '1984-10-23 00:00:00'),
(7, 1, 'Building Pong in JavaScript', 'Here is a basic game created using HTML 5 and vanilla javascript', 'images/linux_mint.png', '2014-11-11 22:06:14'),
(12, 1, 'Another Basic Test; illegal code<>;', 'Please delete me thank you full securityentities', 'images/linux_mint.png', '2014-11-18 13:42:00'),
(13, 1, 'Another Basic Test; illegal code&lt;&gt;;', 'Please delete me thank you full securityentities', 'images/linux_mint.png', '2014-11-18 13:46:43'),
(14, 1, 'Amazing Things To See In Linuxland', 'This is a repository for all the little applets I find to enhance Mint 17.', 'images/linux_mint.png', '2014-11-18 15:03:28');

-- --------------------------------------------------------

--
-- Table structure for table `Course`
--

CREATE TABLE IF NOT EXISTS `Course` (
  `courseId` int(11) NOT NULL AUTO_INCREMENT,
  `courseName` varchar(30) NOT NULL,
  `courseTutor` varchar(40) NOT NULL,
  `faculty` enum('Computing','Business','Engineering','Science','Performing Arts') NOT NULL,
  PRIMARY KEY (`courseId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `Course`
--

INSERT INTO `Course` (`courseId`, `courseName`, `courseTutor`, `faculty`) VALUES
(1, 'Web Programming', 'Julia Hunter', 'Computing'),
(2, 'Modern System Architecture', 'Masud Rahman', 'Computing'),
(3, 'Object Oriented Programming', 'Julia Hunter', 'Computing'),
(4, 'Work Based Learning', 'Carol Farrance', 'Business'),
(7, 'Economics', 'Alan Sugar', 'Business'),
(8, 'Marketing Principles', 'Simon Cowell', 'Business'),
(9, 'Molecular Physics', 'Gordon Freeman', 'Science'),
(10, 'Xenobiology', 'Ellen Ripley', 'Science'),
(11, 'Automotive Aerodynamics', 'Gordon Murray', 'Engineering'),
(12, 'Zero-G Astroengineering', 'Isaac Clarke', 'Engineering'),
(13, 'Contemporary Dance', 'Brian Friedman', 'Performing Arts'),
(14, 'Vocal Acrobatics', 'Smooth McGroove', 'Performing Arts');

-- --------------------------------------------------------

--
-- Table structure for table `Facebook`
--

CREATE TABLE IF NOT EXISTS `Facebook` (
  `facebookId` varchar(40) NOT NULL,
  `pass` varchar(30) NOT NULL,
  `studentId` int(10) NOT NULL,
  PRIMARY KEY (`facebookId`),
  KEY `facebookId` (`facebookId`),
  KEY `studentId` (`studentId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Facebook`
--


-- --------------------------------------------------------

--
-- Table structure for table `Register`
--

CREATE TABLE IF NOT EXISTS `Register` (
  `registerId` int(11) NOT NULL AUTO_INCREMENT,
  `studentId` int(11) NOT NULL,
  `courseId` int(11) NOT NULL,
  `grade` int(3) DEFAULT NULL COMMENT '(%)',
  PRIMARY KEY (`registerId`),
  KEY `studentId` (`studentId`),
  KEY `courseId` (`courseId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=93 ;

--
-- Dumping data for table `Register`
--

INSERT INTO `Register` (`registerId`, `studentId`, `courseId`, `grade`) VALUES
(9, 1, 1, NULL),
(10, 1, 2, NULL),
(11, 1, 3, NULL),
(12, 2, 1, 80),
(13, 2, 3, 75),
(51, 3, 11, NULL),
(52, 3, 12, NULL),
(53, 4, 1, NULL),
(54, 4, 2, NULL),
(55, 6, 7, NULL),
(56, 6, 8, NULL),
(57, 7, 2, NULL),
(58, 7, 3, NULL),
(59, 8, 7, NULL),
(60, 8, 8, NULL),
(61, 9, 9, NULL),
(62, 9, 10, NULL),
(63, 10, 10, NULL),
(64, 11, 11, NULL),
(65, 12, 7, NULL),
(66, 13, 11, NULL),
(67, 14, 14, NULL),
(68, 15, 12, NULL),
(69, 16, 13, NULL),
(70, 17, 11, NULL),
(71, 18, 14, NULL),
(72, 19, 9, NULL),
(73, 20, 11, NULL),
(74, 21, 12, NULL),
(75, 32, 9, NULL),
(76, 31, 10, NULL),
(77, 23, 9, NULL),
(78, 29, 13, NULL),
(79, 25, 14, NULL),
(80, 42, 13, NULL),
(81, 30, 1, NULL),
(82, 22, 2, NULL),
(83, 24, 3, NULL),
(84, 26, 4, NULL),
(85, 27, 7, NULL),
(86, 33, 8, NULL),
(87, 33, 7, NULL),
(88, 32, 10, NULL),
(89, 25, 13, NULL),
(90, 22, 1, NULL),
(91, 46, 3, NULL),
(92, 51, 7, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Student`
--

CREATE TABLE IF NOT EXISTS `Student` (
  `studentId` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(20) NOT NULL,
  `lastName` varchar(30) NOT NULL,
  `email` varchar(40) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `pass` varchar(30) NOT NULL,
  `dob` date NOT NULL,
  `userImage` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`studentId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=52 ;

--
-- Dumping data for table `Student`
--

INSERT INTO `Student` (`studentId`, `firstName`, `lastName`, `email`, `username`, `pass`, `dob`, `userImage`) VALUES
(1, 'Adrian', 'Leach', 'adriansemail@email.com', 'adrianl8113', 'secret', '1980-10-18', 'images/linux_mint.png'),
(2, 'Bruce', 'Wayne', 'alterego@gotham.com', NULL, '', '0000-00-00', NULL),
(3, 'Amanda', 'Ripley', 'hidinginalocker@sevastopol.com', NULL, '', '0000-00-00', NULL),
(4, 'Jon', 'Snow', 'coolguy@thewall.com', NULL, '', '0000-00-00', NULL),
(6, 'Roger', 'Harris', 'rogersemail@home.com', 'rogerh1234', '1234567', '1978-12-20', NULL),
(7, 'Elyssia', 'Rivers', 'name@address.com', 'demir1234', '', '0000-00-00', NULL),
(8, 'Demi', 'Austin', 'demi@address.com', 'demia1234', '', '0000-00-00', NULL),
(9, 'Rhiannon', 'Austin', 'rhitin@testing.com', 'rhiannona1234', '', '0000-00-00', NULL),
(10, 'Grumpy', 'Bear', NULL, NULL, '', '0000-00-00', NULL),
(11, 'Gordon', 'Freeman', NULL, NULL, 'password1', '1989-12-01', NULL),
(12, 'Willy', 'Wonka', NULL, NULL, 'password2', '1899-12-06', NULL),
(13, 'Engelbert', 'Humperdink', NULL, NULL, 'password4', '2000-06-27', NULL),
(14, 'George', 'Likesshouting', NULL, NULL, 'password6', '2000-08-25', NULL),
(15, 'David', 'Hayter', NULL, NULL, 'password7', '2000-08-25', NULL),
(16, 'Alan', 'Carr', NULL, NULL, 'comic1', '1970-05-25', NULL),
(17, 'Bob', 'Star', NULL, NULL, 'eagle1', '1975-05-29', NULL),
(18, 'Peter', 'Parker', NULL, NULL, 'spidey', '1985-05-29', NULL),
(19, 'Bruce', 'Banner', 'hulk@hulksmash.com', 'drbanner', 'green', '1985-05-29', NULL),
(20, 'Steve', 'Rogers', 'chargingstar@usa.com', 'thecaptain', 'bucky', '1918-07-04', NULL),
(21, 'Tali ''Zorah', 'vas Normandy', 'gettingvacinated@ssvnormandy.com', 'taliz', 'shepard', '2161-12-20', NULL),
(22, 'Shigeru', 'Miyamoto', 'stillgreat@nintendo.co.jp', 'issamemario', 'bowser', '1969-11-06', NULL),
(23, 'Christopher', 'Nolan', 'engrossed@comiccon.com', 'chrisn666', 'smvsbm', '1945-07-19', NULL),
(24, 'Snow', 'Villiers', 'hero@nora.org', 'papasnow', 'serahfarron', '2020-07-21', NULL),
(25, 'Elhaym', 'Van Houten', 'elly@solaris.org', 'ellyvh111', 'vierge', '2123-05-15', NULL),
(26, 'Squall', 'Leonhart', 'sullenbutcaring@balambgarden.edu', 'griever1', 'rinoa', '1999-01-12', NULL),
(27, 'Tifa', 'Lockhart', 'tifa@seventhheaven.com', 'tifal7777', 'smilecloud', '2002-03-16', NULL),
(29, 'Citan', 'Uzuki', 'doc@lahanvillage.com', 'hyuga', 'heimdal', '0000-00-00', NULL),
(30, 'Ken', 'Masters', 'ceo@masterscorp.com', 'kenmasters', 'shotokan', '1975-06-30', NULL),
(31, 'Cammy', 'White', 'killerbee@mi5.org', 'cammy', 'whykylie', '1985-11-11', NULL),
(32, 'Bartholomew', 'Fatima', 'bart@yggdrasil.com', 'princebart', 'andvari', '1990-04-12', NULL),
(33, 'Tux', 'Penguin', 'thetux@linux.org', 'mintytux', 'mint17', '1999-12-25', 'images/linux_mint.png'),
(42, 'Karen', 'Pippen', 'karen@regex.com', 'jolly', 'beetle', '2000-11-19', ''),
(46, 'Shaun', 'Sheep', 'shaun@baabaa.com', 'wooly1', 'shaunsheep', '2000-10-19', NULL),
(51, 'Emily', 'Elephant', 'emily@baabaa.com', 'emily1', 'tusktusk', '2009-06-19', NULL);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Content`
--
ALTER TABLE `Content`
  ADD CONSTRAINT `Content_ibfk_1` FOREIGN KEY (`owner`) REFERENCES `Student` (`studentId`);

--
-- Constraints for table `Facebook`
--
ALTER TABLE `Facebook`
  ADD CONSTRAINT `Facebook_ibfk_1` FOREIGN KEY (`studentId`) REFERENCES `Student` (`studentId`);

--
-- Constraints for table `Register`
--
ALTER TABLE `Register`
  ADD CONSTRAINT `Register_ibfk_1` FOREIGN KEY (`courseId`) REFERENCES `Course` (`courseId`),
  ADD CONSTRAINT `Register_ibfk_2` FOREIGN KEY (`studentId`) REFERENCES `Student` (`studentId`);
